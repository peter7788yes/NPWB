using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyDescription("IISI for PRSB Auto Update")]
[assembly: Guid("e07ff206-1b04-4b32-a5fd-89f097ecffef")]
[assembly: AssemblyCopyright("Copyright ©  IISI 2016")]
[assembly: AssemblyProduct("NPWB")]
[assembly: AssemblyFileVersion("1.0.2.1")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("IISI")]
[assembly: AssemblyTitle("NPWB")]
[assembly: AssemblyCompany("IISI")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyVersion("1.0.2.1")]
