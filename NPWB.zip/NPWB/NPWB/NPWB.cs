using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using NPWB.My.Resources;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using SystemIO.zip;

namespace NPWB
{
	[DesignerGenerated]
	public class NPWB : Form
	{
		private IContainer components;

		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		[AccessedThroughProperty("ListView1")]
		private ListView _ListView1;

		[AccessedThroughProperty("PictureBox1")]
		private PictureBox _PictureBox1;

		[AccessedThroughProperty("TreeView1")]
		private TreeView _TreeView1;

		[AccessedThroughProperty("ListBox1")]
		private ListBox _ListBox1;

		private const string UserType = "NUP";

		private string ErrStr;

		private string appPath;

		private Zip E2UL;

		private bool UseProxy;

		private string ProxyURL;

		internal virtual Button Button1
		{
			get
			{
				return _Button1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(Button1_Click);
				if (_Button1 != null)
				{
					_Button1.Click -= value2;
				}
				_Button1 = value;
				if (_Button1 != null)
				{
					_Button1.Click += value2;
				}
			}
		}

		internal virtual Button Button2
		{
			get
			{
				return _Button2;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(Button2_Click);
				if (_Button2 != null)
				{
					_Button2.Click -= value2;
				}
				_Button2 = value;
				if (_Button2 != null)
				{
					_Button2.Click += value2;
				}
			}
		}

		internal virtual ListView ListView1
		{
			get
			{
				return _ListView1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				_ListView1 = value;
			}
		}

		internal virtual PictureBox PictureBox1
		{
			get
			{
				return _PictureBox1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				_PictureBox1 = value;
			}
		}

		internal virtual TreeView TreeView1
		{
			get
			{
				return _TreeView1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				_TreeView1 = value;
			}
		}

		internal virtual ListBox ListBox1
		{
			get
			{
				return _ListBox1;
			}
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				_ListBox1 = value;
			}
		}

		public NPWB()
		{
			base.Load += new EventHandler(NPWB_Load);
			base.FormClosed += new FormClosedEventHandler(NPWB_FormClosed);
			ErrStr = "";
			appPath = "";
			E2UL = new Zip();
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && components != null)
				{
					components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		[System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NPWB.NPWB));
			Button1 = new System.Windows.Forms.Button();
			Button2 = new System.Windows.Forms.Button();
			ListView1 = new System.Windows.Forms.ListView();
			PictureBox1 = new System.Windows.Forms.PictureBox();
			TreeView1 = new System.Windows.Forms.TreeView();
			ListBox1 = new System.Windows.Forms.ListBox();
			((System.ComponentModel.ISupportInitialize)PictureBox1).BeginInit();
			SuspendLayout();
			Button1.BackColor = System.Drawing.Color.FromArgb(18, 156, 1);
			Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Button1.Font = new System.Drawing.Font("新細明體", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 136);
			Button1.ForeColor = System.Drawing.Color.White;
			System.Drawing.Point point2 = Button1.Location = new System.Drawing.Point(98, 270);
			Button1.Name = "Button1";
			System.Drawing.Size size2 = Button1.Size = new System.Drawing.Size(153, 34);
			Button1.TabIndex = 0;
			Button1.Text = "直接進行作業";
			Button1.UseVisualStyleBackColor = false;
			Button1.Visible = false;
			Button2.BackColor = System.Drawing.Color.FromArgb(18, 156, 1);
			Button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			Button2.Font = new System.Drawing.Font("新細明體", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 136);
			Button2.ForeColor = System.Drawing.Color.White;
			point2 = (Button2.Location = new System.Drawing.Point(313, 270));
			Button2.Name = "Button2";
			size2 = (Button2.Size = new System.Drawing.Size(104, 34));
			Button2.TabIndex = 1;
			Button2.Text = "結束";
			Button2.UseVisualStyleBackColor = false;
			Button2.Visible = false;
			point2 = (ListView1.Location = new System.Drawing.Point(376, 196));
			ListView1.Name = "ListView1";
			size2 = (ListView1.Size = new System.Drawing.Size(55, 18));
			ListView1.TabIndex = 2;
			ListView1.UseCompatibleStateImageBehavior = false;
			ListView1.Visible = false;
			PictureBox1.BackColor = System.Drawing.Color.Transparent;
			PictureBox1.ErrorImage = null;
			PictureBox1.Image = NPWB.My.Resources.Resources.Banner;
			PictureBox1.InitialImage = null;
			point2 = (PictureBox1.Location = new System.Drawing.Point(40, 3));
			PictureBox1.Name = "PictureBox1";
			size2 = (PictureBox1.Size = new System.Drawing.Size(538, 66));
			PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			PictureBox1.TabIndex = 3;
			PictureBox1.TabStop = false;
			point2 = (TreeView1.Location = new System.Drawing.Point(21, 196));
			TreeView1.Name = "TreeView1";
			size2 = (TreeView1.Size = new System.Drawing.Size(36, 18));
			TreeView1.TabIndex = 4;
			TreeView1.Visible = false;
			ListBox1.BackColor = System.Drawing.Color.White;
			ListBox1.Font = new System.Drawing.Font("標楷體", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 136);
			ListBox1.ForeColor = System.Drawing.Color.Black;
			ListBox1.FormattingEnabled = true;
			ListBox1.ItemHeight = 15;
			ListBox1.Items.AddRange(new object[1]
			{
				"系統載入中....................."
			});
			point2 = (ListBox1.Location = new System.Drawing.Point(12, 65));
			ListBox1.Name = "ListBox1";
			size2 = (ListBox1.Size = new System.Drawing.Size(539, 199));
			ListBox1.TabIndex = 5;
			System.Drawing.SizeF sizeF2 = AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.White;
			BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			CancelButton = Button2;
			size2 = (ClientSize = new System.Drawing.Size(563, 316));
			Controls.Add(ListBox1);
			Controls.Add(TreeView1);
			Controls.Add(ListView1);
			Controls.Add(Button2);
			Controls.Add(Button1);
			Controls.Add(PictureBox1);
			Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			MaximizeBox = false;
			MinimizeBox = false;
			Name = "NPWB";
			StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "自動更新";
			((System.ComponentModel.ISupportInitialize)PictureBox1).EndInit();
			ResumeLayout(false);
		}

		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void Button2_Click(object sender, EventArgs e)
		{
			ProjectData.EndApp();
		}

		private void Button1_Click(object sender, EventArgs e)
		{
			NextStep();
		}

		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void NPWB_FormClosed(object sender, FormClosedEventArgs e)
		{
			ProjectData.EndApp();
		}

		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void NPWB_Load(object sender, EventArgs e)
		{
			ServicePointManager.SecurityProtocol = (SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12);
			Process[] processesByName = Process.GetProcessesByName("NPWB");
			Process[] processesByName2 = Process.GetProcessesByName("PWNS");
			if ((processesByName.Length > 1) | (processesByName2.Length > 0))
			{
				Interaction.MsgBox("程式已開啟!!", MsgBoxStyle.Exclamation, E2UFunction.Title);
				ProjectData.EndApp();
			}
			appPath = Interaction.GetSetting("PRSB", "main", "TestPath", Application.StartupPath);
			if (Operators.CompareString(Strings.Right(appPath, 1), "\\", false) != 0)
			{
				appPath += "\\";
			}
			Show();
			UseProxy = (Operators.CompareString(Interaction.GetSetting("PRSB", "main", "PROXY"), "U", false) == 0);
			ProxyURL = Interaction.GetSetting("PRSB", "main", "ProxyUrl");
			Application.DoEvents();
			Update_From_Web();
			Button2.Visible = true;
		}

		private void Update_From_Web()
		{
			ListBox1.Items.Add("連結網站檢查更新中.......請稍待....");
			Application.DoEvents();
			if (Operators.CompareString(Interaction.GetSetting("PRSB", "main", "num"), "", false) == 0)
			{
				Interaction.SaveSetting("PRSB", "main", "num", "0");
				Interaction.SaveSetting("PRSB", "main", "file_ser0", "100000");
				Interaction.SaveSetting("PRSB", "main", "IP", "https://prsbedi.prsb.gov.tw");
				Interaction.SaveSetting("PRSB", "main", "Reload_time", Conversions.ToString(30));
				Interaction.SaveSetting("PRSB", "main", "timeout", Conversions.ToString(90));
				Interaction.SaveSetting("PRSB", "main", "dir", FileSystem.CurDir());
				Interaction.SaveSetting("PRSB", "main", "Code0", "");
			}
			string address = Interaction.GetSetting("PRSB", "main", "IP", "https://prsbedi.prsb.gov.tw") + "/Web2/LoadProg.aspx?SN=" + E2UFunction.Tns4Send("M,M");
			string text = "";
			WebClient webClient = new WebClient();
			if (UseProxy)
			{
				if (Operators.CompareString(ProxyURL, "", false) == 0)
				{
					webClient.Proxy = WebRequest.DefaultWebProxy;
				}
				else
				{
					WebProxy webProxy = new WebProxy();
					webProxy.Address = new Uri(ProxyURL);
					webClient.Proxy = webProxy;
				}
			}
			webClient.Encoding = Encoding.UTF8;
			try
			{
				text = webClient.DownloadString(address);
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				ErrStr = ex2.Message;
				ProjectData.ClearProjectError();
			}
			checked
			{
				if (Operators.CompareString(Strings.Mid(text, 1, 2), "E;", false) == 0)
				{
					string[] array = Strings.Split(text, ";", -1, CompareMethod.Text);
					short num = (short)Information.UBound(array);
					for (short num2 = 1; num2 <= num; num2 = (short)unchecked(num2 + 1))
					{
						string[] array2 = Strings.Split(array[num2], ",", -1, CompareMethod.Text);
						if (!File.Exists(appPath + array2[0]) || FileSystem.FileDateTime(appPath + array2[0]).ToOADate() < Conversions.ToDouble(array2[2]))
						{
							ListBox1.Items.Add("下載->" + array2[1] + " 處理中....");
							DodownLoad(array2[0], ref array2[1], array2[3]);
						}
					}
				}
				if (Operators.CompareString(ErrStr, "", false) == 0)
				{
					NextStep();
					return;
				}
				ListBox1.Items.Add("連結網站更新失敗...");
				ListBox1.Items.Add("更新系統異常");
				ListBox1.Items.Add("錯誤說明 :" + ErrStr);
				ListBox1.Items.Add("回覆畫面->");
				ListBox1.Items.Add(text);
				ListBox1.Items.Add("請稍後再執行 或");
				ListBox1.Items.Add("聯絡系統管理員,並點選結束關閉作業");
			}
		}

		private void DodownLoad(string File4Down, ref string FileDesc, string FilePack)
		{
			string noteString = "NUP" + Interaction.GetSetting("PRSB", "main", "Code" + Interaction.GetSetting("PRSB", "main", "num", "0")) + Strings.Format(DateAndTime.Now, "yyyyMMddhhmmss.fff");
			string address = Interaction.GetSetting("PRSB", "main", "IP") + "/Web2/DLProg.aspx?SN=" + E2UFunction.Tns4Send("P;" + FilePack + ";1969");
			try
			{
				if (File.Exists(appPath + FilePack))
				{
					File.Delete(appPath + FilePack);
				}
				if (Operators.CompareString(File4Down, "NPWB.exe", false) == 0)
				{
					if (File.Exists(appPath + "$NPWB.exe"))
					{
						File.Delete(appPath + "$NPWB.exe");
					}
				}
				else
				{
					if (File.Exists(appPath + File4Down + ".bak"))
					{
						File.Delete(appPath + File4Down + ".bak");
					}
					if (File.Exists(appPath + File4Down))
					{
						File.Move(appPath + File4Down, appPath + File4Down + ".bak");
					}
				}
				WebClient webClient = new WebClient();
				webClient.DownloadFile(address, appPath + FilePack);
				int num = E2UL.DeCode(appPath + FilePack, appPath, ">A\\&U]t1zYxM|!QWC :C^4@;", noteString);
				File.Delete(appPath + FilePack);
				if (num == 0)
				{
					ListBox1.Items.Add("更新->" + FileDesc + " 處理完成....");
					return;
				}
				ListBox1.Items.Add("更新->" + FileDesc + " 處理失敗-->" + Conversions.ToString(num));
				ListBox1.Items.Add("錯誤說明:" + E2UL.ErrToString(num));
				ErrStr = E2UL.ErrToString(num);
			}
			catch (Exception ex)
			{
				ProjectData.SetProjectError(ex);
				Exception ex2 = ex;
				ErrStr = ex2.Message;
				ListBox1.Items.Add("下載->" + FileDesc + " 失敗....");
				ListBox1.Items.Add("可能是權限問題，請改以系統管理員身份重新再執行本系統");
				ProjectData.ClearProjectError();
			}
		}

		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void NextStep()
		{
			Interaction.SaveSetting("PRSB", "main", "E2U", "IISI");
			if (Directory.GetFiles(appPath, "$*").Length == 0)
			{
				if ((Screen.PrimaryScreen.Bounds.Width < 1010) | (Screen.PrimaryScreen.Bounds.Height < 680))
				{
					if (File.Exists(appPath + "PWNSL.exe"))
					{
						Interaction.Shell(appPath + "PWNSL.exe", AppWinStyle.NormalFocus);
					}
					else
					{
						Interaction.Shell(appPath + "PWNS.exe", AppWinStyle.NormalFocus);
					}
				}
				else
				{
					Interaction.Shell(appPath + "PWNS.exe", AppWinStyle.NormalFocus);
				}
			}
			else
			{
				Interaction.Shell(appPath + "NPWC.exe", AppWinStyle.NormalFocus);
			}
			ProjectData.EndApp();
		}
	}
}
