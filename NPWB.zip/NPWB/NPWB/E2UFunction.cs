using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System;

namespace NPWB
{
	[StandardModule]
	internal sealed class E2UFunction
	{
		public static string Title = "業務資料傳輸系統";

		private static string TnsXcode;

		public static string Tns4PassR(string data_str)
		{
			TnsXcode = "sCIKtx9e0obp6*c1fVTkvXNByJur4EDg3UFW5Yz2iGjm'AOR7hnQw8ZPqaL,MSHdl.";
			return Tns4R(data_str);
		}

		public static string Tns4Recv(string data_str)
		{
			TnsXcode = "IKVTkoHd*c1ZPqaz2iFtg3UL,ur4EDAJW5Bfvb6SXGy7hn'Qw8sCMx9eYjmN0ORlp.";
			return Tns4R(data_str);
		}

		private static string Tns4R(string data_str)
		{
			short num = 0;
			short num2 = 0;
			string text = "";
			checked
			{
				short num3 = (short)Strings.InStr(TnsXcode, Strings.Mid(data_str, 1, 1));
				if ((num3 == 0) | (Operators.CompareString(data_str, "", false) == 0))
				{
					return "";
				}
				num3 = (short)(Strings.InStr(TnsXcode, Strings.Mid(data_str, 1, 1)) + 1);
				int num4 = Strings.Len(data_str);
				for (int i = 2; i <= num4; i++)
				{
					short num5 = (short)Strings.InStr(TnsXcode, Strings.Mid(data_str, i, 1));
					if (num5 == 66)
					{
						num = unchecked((short)((num == 0) ? 64 : 0));
						num2 = (short)(num2 + 1);
						continue;
					}
					num5 = (short)((short)unchecked(checked((short)unchecked(num5 + num)) - num3) - i + 1 + num2);
					if (num5 < 0)
					{
						num5 = (short)(num5 + 128);
					}
					text += Conversions.ToString(Strings.Chr(num5));
				}
				return text;
			}
		}

		public static string Tns4PassE(string data_str)
		{
			TnsXcode = "sCIKtx9e0obp6*c1fVTkvXNByJur4EDg3UFW5Yz2iGjm'AOR7hnQw8ZPqaL,MSHdl.";
			return Tns4S(data_str);
		}

		public static string Tns4Send(string TransStr)
		{
			TnsXcode = "IKVTkoHd*c1ZPqaz2iFtg3UL,ur4EDAJW5Bfvb6SXGy7hn'Qw8sCMx9eYjmN0ORlp.";
			return Tns4S(TransStr);
		}

		private static string Tns4S(string TransStr)
		{
			if (Operators.CompareString(TransStr, "", false) == 0)
			{
				return "";
			}
			VBMath.Randomize(DateAndTime.Now.ToOADate());
			checked
			{
				int num = (int)Math.Round(Conversion.Int(VBMath.Rnd() * 63f) + 1f);
				bool flag = false;
				string text = Strings.Mid(TnsXcode, num, 1);
				int num2 = Strings.Len(TransStr);
				for (int i = 1; i <= num2; i++)
				{
					int num3 = Strings.Asc(Strings.Mid(TransStr, i, 1)) + num + i;
					num3 = unchecked(num3 % 128);
					if (num3 > 63)
					{
						if (!flag)
						{
							text += ".";
							flag = true;
						}
						num3 -= 64;
					}
					else if (flag)
					{
						text += ".";
						flag = false;
					}
					text += Strings.Mid(TnsXcode, num3 + 1, 1);
				}
				return text;
			}
		}
	}
}
